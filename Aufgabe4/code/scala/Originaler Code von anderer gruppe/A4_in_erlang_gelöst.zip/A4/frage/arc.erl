-module (arc).
-export ([newArc/3]).

newArc(VertexX,VertexY,Constraint) ->
	{VertexX,VertexY,Constraint}.

