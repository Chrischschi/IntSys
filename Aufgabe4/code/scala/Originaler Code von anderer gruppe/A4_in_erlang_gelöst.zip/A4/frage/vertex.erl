-module (vertex).
-export ([newVertex/2,getDefRange/1,getName/1]).

newVertex(DefRange,Name) ->
	{DefRange,Name}.

getDefRange(Vertex) ->
	{DefRange, _} = Vertex,
	DefRange.

getName(Vertex) ->
	{_,Name} = Vertex,
	Name.