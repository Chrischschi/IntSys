-module (algos).
-export ([ac3_la/3,nc/1]).

revise([Vars|[T]],{SourceX,TargetX,Constrains}) ->
	[{Source,SourceRange}] = [{Source,Srange}||{Source,Srange} <- Vars, Source == SourceX],
	[{_,SourceTarget}] = [{Target, TRange}|| {Target, TRange} <- Vars, Target == TargetX],
	{Accu, Bool} = revise_for_each_x(SourceRange,SourceTarget,Constrains),
	NewData = data:setRange(Source,Accu, [Vars,T]),
	{NewData, Bool}.

revise_for_each_x(DefRangeX, DefRangeY,Constrain) ->
	Accu = [X || X <- DefRangeX, lists:member(X,[X||Y <- DefRangeY, revise_for_each_x_(X,Y,Constrain,true)])],
	Bool = DefRangeX /= Accu,
	{Accu, Bool}.

revise_for_each_x_(_,_,[],Bool) ->
	Bool;
revise_for_each_x_(X,Y,[Con|RestCons],Bool) ->
	revise_for_each_x_(X,Y,RestCons, (constraints:constraint(X,Y,Con) and Bool)).

ac3_la(Data,_,RestVars) ->
	Consistent = true,
	[CVVar|RestVars_] = RestVars,
	Q = getArcs(Data, CVVar,RestVars_),
	ac3_la_while(Q, Data,RestVars,Consistent).

ac3_la_while([],Data,_,true) ->
	{Data,true};
ac3_la_while(_,_,_,false) ->
	{[],false};
ac3_la_while(Q,Data,RestVars,true) ->
	[AnyArc|ResArc] = Q,
	{NewData, Bool} = revise(Data,AnyArc),
	[_|[AllArcs]] = NewData,
	{Vk,Vm,_} = AnyArc,
	VkRange = data:getRange(Vk,NewData),
	case Bool of
		true ->
			NewQ = myunion(ResArc,AllArcs,RestVars,Vm,Vk),
			ac3_la_while(NewQ,NewData,RestVars,length(VkRange) /= 0);
		false ->
			ac3_la_while(ResArc,NewData,RestVars,length(VkRange) /= 0)
	end.



getArcs(Data,{CVVar,_},RestVars) ->
	[_|[Arcs]] = Data,
	[{Source, Target, Cons} || {Source,Target,Cons} <- Arcs, varMember(Source, RestVars),CVVar == Target].

varMember(Source,RestVars) ->
	length([Name|| {Name,_} <- RestVars, Name == Source]) == 1.


myunion(ResArc,AllArcs,RestVars,Vm,Vk) ->
	NewList =[{Source,Target,Cons}|| {Source,Target,Cons} <- AllArcs, Source /= Vk, Source /= Vm, Vk == Target, varMember(Source, RestVars)],
	ResArc ++ NewList.

nc([Vars|[Arcs]]) ->
	NewVars = nc_(Vars,[{Source,Target,Cons} || {Source,Target,Cons} <- Arcs , Source == Target]),
	[NewVars,Arcs].

nc_(Vars,[]) ->
	Vars;
nc_(Vars, Cons) ->
	[{Name,_,ThisCons}|Rest] = Cons,
	Range = data:getRange(Name,[Vars,[]]),
	NewRange = [X|| X <- Range, nc__(ThisCons,X,true)],
	[NewVars,_] = data:setRange(Name,NewRange,[Vars,[]]),
	nc_(NewVars,Rest).

nc__([],_,Bool) ->
	Bool;
nc__([Con|T],X,Bool) ->
	nc__(T,X,Bool and constraints:constraint(X,X,Con)).






