-module (einsteinRaetsel).
-export ([go/0]).
go() ->
	{Data,Bool} = solver:getSolution(einsteinModell:getModell()),
	print(Data,Bool).

print(_,error) ->
	"KEINE LOESUNG GEFUNDEN!!";
print([Vars|_],ok) ->
	[getHaus(1,Vars),getHaus(2,Vars),getHaus(3,Vars),getHaus(4,Vars),getHaus(5,Vars)].


getHaus(Nummer,Vars) ->
	[X|| {X,[Y]} <- Vars, Y == Nummer].


