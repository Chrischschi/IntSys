-module (constraints).
-export ([constraint/3]).

constraint(VarX,VarY,eql) ->
	VarX == VarY;
constraint(VarX,_,{eql,To}) ->
	VarX == To;
constraint(VarX,VarY,noteql) ->
	VarX /= VarY;
constraint(VarX,VarY,neig) ->
	abs(VarX - VarY) == 1;
constraint(VarX,VarY,leftneig) ->
	(VarX - VarY) == 1;
constraint(VarX,VarY,rightneig) ->
	(VarY - VarX) == 1;
constraint(VarX,VarY,_) ->
	{VarX,VarY,error}.
