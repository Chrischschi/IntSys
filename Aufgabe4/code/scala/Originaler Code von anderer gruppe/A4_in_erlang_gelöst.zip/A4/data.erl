-module (data).
-export ([getRange/2,setRange/3]).

getRange(NameX, [Vars|_]) ->
	[Result] = [Range|| {X,Range} <- Vars, ((X == NameX))],
	Result.

setRange(NameX,NewRange,[Vars|[Cons]]) ->
	NewVars = [setRange_(NameX,X,Range,NewRange,null)|| {X,Range} <- Vars],
	%[Cons_] = Cons,
	[NewVars,Cons].
	
setRange_(NameX, X,OldRange,NewRange,null) ->
	setRange_(NameX,X,OldRange,NewRange, NameX == X);
setRange_(_,X,_,NewRange,true) ->
	{X,NewRange};
setRange_(_,X,OldRange,_,false) ->
	{X,OldRange}.