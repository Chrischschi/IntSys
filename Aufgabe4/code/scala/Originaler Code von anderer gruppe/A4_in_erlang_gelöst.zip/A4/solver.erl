-module (solver).
-export ([getSolution/1]).


getSolution(Data) ->
	[Vars|_] = NewData = algos:nc(Data),
	{New2Data,_} = algos:ac3_la(NewData,[],Vars),
	io:fwrite('HALLO->~n~p', [New2Data]),
	%io:fwrite('~p~n',Vars)
	getSolution_(New2Data,[],Vars).

getSolution_(Data,_,[]) ->
	{Data,ok};
getSolution_(_,_,[{Name,[]}|_]) ->
	{Name,error};
getSolution_(Data, PastVars, RestVars) ->
	[CVar|Tail] = RestVars,
	{Name,_} = CVar,
	[NewRange|RestRange] = data:getRange(Name,Data),	
	WorkData = data:setRange(Name,[NewRange],Data), 
	{NewData, Bool} = algos:ac3_la(WorkData,[],RestVars),
	case Bool of
		true ->
			NextData = data:setRange(Name,RestRange,Data),
			NewCVar = {Name,RestRange},
			getSolution__(getSolution_(NewData, PastVars ++ [CVar], Tail),NextData,NewCVar, PastVars,Tail);
		false ->
			NextData = data:setRange(Name,RestRange,Data),
			NewCVar = {Name,RestRange},
			getSolution_(NextData, PastVars, [NewCVar] ++ Tail)
	end.

getSolution__({Data,ok},_,_,_,_) ->
	{Data,ok};
getSolution__({_,error},NextData,NewCVar,PastVars,Tail) ->
	getSolution_(NextData, PastVars, [NewCVar] ++ Tail).




