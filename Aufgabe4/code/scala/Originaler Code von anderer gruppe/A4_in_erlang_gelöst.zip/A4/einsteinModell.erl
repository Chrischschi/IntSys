-module (einsteinModell).
-export ([getModell/0]).

getModell() ->
	%Constraint-Net
	[
	%Variables
	[
		{norweger,[1,2,3,4,5]},
		{daene,[1,2,3,4,5]},
		{deutscher,[1,2,3,4,5]},
		{britte,[1,2,3,4,5]},
		{schwede,[1,2,3,4,5]},

		{rot,[1,2,3,4,5]},
		{weiss,[1,2,3,4,5]},
		{blau,[1,2,3,4,5]},
		{grun,[1,2,3,4,5]},
		{gelb,[1,2,3,4,5]},

		{hund,[1,2,3,4,5]},
		{fisch,[1,2,3,4,5]},
		{pferd,[1,2,3,4,5]},
		{katze,[1,2,3,4,5]},
		{vogel,[1,2,3,4,5]},

		{dunhill,[1,2,3,4,5]},
		{pallmall,[1,2,3,4,5]},
		{malboro,[1,2,3,4,5]},
		{rothmanns,[1,2,3,4,5]},
		{winfield,[1,2,3,4,5]},

		{milch,[1,2,3,4,5]},
		{tee,[1,2,3,4,5]},
		{kaffee,[1,2,3,4,5]},
		{bier,[1,2,3,4,5]},
		{wasser,[1,2,3,4,5]}

	],
	%Arcs
	[
	%Nationen
		{daene,deutscher,[noteql]},
		{daene,britte,[noteql]},
		{daene,schwede,[noteql]},
		{daene,norweger,[noteql]},

		{deutscher,daene,[noteql]},
		{deutscher,britte,[noteql]},
		{deutscher,schwede,[noteql]},
		{deutscher,norweger,[noteql]},

		{britte,daene,[noteql]},
		{britte,deutscher,[noteql]},
		{britte,schwede,[noteql]},
		{britte,norweger,[noteql]},

		{schwede,daene,[noteql]},
		{schwede,deutscher,[noteql]},
		{schwede,britte,[noteql]},
		{schwede,norweger,[noteql]},

		{norweger,daene,[noteql]},
		{norweger,deutscher,[noteql]},
		{norweger,britte,[noteql]},
		{norweger,schwede,[noteql]},
	%Hausfarben

		{rot,weiss,[noteql]},
		{rot,blau,[noteql]},
		{rot,grun,[noteql]},
		{rot,gelb,[noteql]},

		{weiss,rot,[noteql]},
		{weiss,blau,[noteql]},
		{weiss,grun,[noteql,leftneig]},
		{weiss,gelb,[noteql]},

		{blau,rot,[noteql]},
		{blau,weiss,[noteql]},
		{blau,grun,[noteql]},
		{blau,gelb,[noteql]},

		{grun,rot,[noteql]},
		{grun,weiss,[noteql,rightneig]},
		{grun,blau,[noteql]},
		{grun,gelb,[noteql]},

		{gelb,rot,[noteql]},
		{gelb,weiss,[noteql]},
		{gelb,blau,[noteql]},
		{gelb,grun,[noteql]},
	%Tiere

		{hund,fisch,[noteql]},
		{hund,pferd,[noteql]},
		{hund,katze,[noteql]},
		{hund,vogel,[noteql]},

		{fisch,hund,[noteql]},
		{fisch,pferd,[noteql]},
		{fisch,katze,[noteql]},
		{fisch,vogel,[noteql]},

		{pferd,hund,[noteql]},
		{pferd,fisch,[noteql]},
		{pferd,katze,[noteql]},
		{pferd,vogel,[noteql]},

		{katze,hund,[noteql]},
		{katze,fisch,[noteql]},
		{katze,pferd,[noteql]},
		{katze,vogel,[noteql]},

		{vogel,hund,[noteql]},
		{vogel,fisch,[noteql]},
		{vogel,pferd,[noteql]},
		{vogel,katze,[noteql]},
	%Zigg

		{dunhill,pallmall,[noteql]},
		{dunhill,malboro,[noteql]},
		{dunhill,rothmanns,[noteql]},
		{dunhill,winfield,[noteql]},

		{pallmall,dunhill,[noteql]},
		{pallmall,malboro,[noteql]},
		{pallmall,rothmanns,[noteql]},
		{pallmall,winfield,[noteql]},

		{malboro,dunhill,[noteql]},
		{malboro,pallmall,[noteql]},
		{malboro,rothmanns,[noteql]},
		{malboro,winfield,[noteql]},

		{rothmanns,dunhill,[noteql]},
		{rothmanns,pallmall,[noteql]},
		{rothmanns,malboro,[noteql]},
		{rothmanns,winfield,[noteql]},

		{winfield,dunhill,[noteql]},
		{winfield,pallmall,[noteql]},
		{winfield,malboro,[noteql]},
		{winfield,rothmanns,[noteql]},
	%Gatrenk

		{milch,tee,[noteql]},
		{milch,kaffee,[noteql]},
		{milch,bier,[noteql]},
		{milch,wasser,[noteql]},

		{tee,milch,[noteql]},
		{tee,kaffee,[noteql]},
		{tee,bier,[noteql]},
		{tee,wasser,[noteql]},

		{kaffee,milch,[noteql]},
		{kaffee,tee,[noteql]},
		{kaffee,bier,[noteql]},
		{kaffee,wasser,[noteql]},

		{bier,milch,[noteql]},
		{bier,tee,[noteql]},
		{bier,kaffee,[noteql]},
		{bier,wasser,[noteql]},

		{wasser,milch,[noteql]},
		{wasser,tee,[noteql]},
		{wasser,kaffee,[noteql]},
		{wasser,bier,[noteql]},

	%Constraint an Hand der AUfgabe
		{tee,daene,[eql]},
		{daene,tee,[eql]},

		{britte,rot,[eql]},
		{rot,britte,[eql]},

		{deutscher,rothmanns,[eql]},
		{rothmanns,deutscher,[eql]},

		{schwede,hund,[eql]},
		{hund,schwede,[eql]},

		{gelb,dunhill,[eql]},
		{dunhill,gelb,[eql]},

		{grun,kaffee,[eql]},
		{kaffee,grun,[eql]},

		{bier,winfield,[eql]},
		{winfield,bier,[eql]},

		{pallmall,vogel,[eql]},
		{vogel,pallmall,[eql]},

		{norweger,norweger,[{eql, 1}]},
		{milch,milch,[{eql,3}]},

		{norweger,blau,[neig]},
		{blau,norweger,[neig]},

		{pferd,dunhill,[neig]},
		{dunhill,pferd,[neig]},

		{malboro,katze,[neig]},
		{katze,malboro,[neig]},

		{malboro,wasser,[neig]},
		{wasser,malboro,[neig]}

	]
	].